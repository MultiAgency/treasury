# MultiAgency SDK

The MultiAgency platform is a control plane for agentic treasuries, built on NEAR Intents. This SDK is how apps and
agents use it.

Build a product interface or an external agent that uses the MultiAgency platform's existing agreements, contribution reports, payments and Treasury workflows. The SDK supplies clients, response schemas and recovery outcomes. The platform keeps identity, authorization, authoritative records and guarded execution.

Start with one supported workflow. A product may provide its own screens, navigation, drafts and preferences while calling the same platform. A new server-side domain or authority model needs a platform extension; importing this package does not create one.

## Install the package

The SDK is MIT-licensed. Install it with:

```text
pnpm add @multiagency/sdk zod@^4.6.5
```

Each package carries `provenance.json`: the source commit it was packed from, any uncommitted paths in that tree, and a digest for every file it was built from. One version number identifies one package: npm does not let a published version be republished with different contents (per npm's documented policy). The package's own README, skills and `CHANGES.md` describe that exact version.

Zod is the one peer: a product's schemas and the SDK's share one Zod. The owner entry (`@multiagency/sdk`) bundles its own `@orpc/client` 2.0.0-beta.47 (licenses in `THIRD-PARTY-NOTICES`) and loads no other oRPC package, so a product on another oRPC version, or a host that shares its own as a Module Federation singleton, keeps it; its bundle then carries both oRPC clients. `@multiagency/sdk/contract` (`ownerContract`, for an app implementing a server from the contract) loads `@orpc/contract` 2.0.0-beta.47, a dependency, as does nothing else. The owner entry also depends on `@ag-ui/core` 1.0.3. The contributor entry loads none of them. The installed package's dependencies and peerDependencies are authoritative for that package. The supported Node target is Node 24. TypeScript consumers use ESM with NodeNext resolution and the ES2023 and DOM libraries for the clients' web request types. The Node-only release-server entry also needs Node typings. `@multiagency/sdk/testing` (Node 24, and offline-checked under Bun 1.4.2: `payoutDouble`, a stand-in for an app's payout agent in the app's own tests) bundles the platform's pure authorization rule and an oRPC server, and loads only zod and `@orpc/contract`; no other entry loads it. Bun is checked offline only: the skills' examples and `payoutDouble` run under Bun 1.4.2 against stand-ins, never against a gateway.

For development against unreleased SDK source, install an SDK repository checkout's dependencies and run `pnpm sdk:dev --once` there, then link your product to its generated `packages/sdk` directory. Use `pnpm sdk:dev` to watch changes. The generated directory is not source and is intentionally absent from Git. A linked checkout can differ from the published package of the same version, so record which one a release was built with, and keep local paths out of portable release inputs.

## Choose the client and supported access

| Product or caller | Client | Required access |
| --- | --- | --- |
| Owner-facing browser product | `ownerClient` from `@multiagency/sdk` | A host-local owner/member session and access to the configured agent |
| Contributor-facing browser product | `payeeClient` from `@multiagency/sdk/payee` | The contributor's session on that contributor entry |
| Contributor's external agent | `payeeClient({ base, token })` | An expiring, revocable report connection started by the contributor |
| A payee checking the policy that pays them | `payeeClient({ base: "https://<platform host>" }).policyProof` | The wallet owner's signed payee disclosure and the payee's own signed read; see payee-workflows |
| Treasury external agent | `ownerClient` with an absolute machine base and a `fetch` that adds the bearer | An existing wallet-owner-issued Treasury credential with the required scopes; see owner-workflows |
| An app's server (for example the MultiAgency dashboard) | `appClient({ base, credential })` from `@multiagency/sdk` | The deployment's operator-issued service credential, plus a live owner consent per Organization and agent |

The platform operator configures a browser product's host, reachable agents and frontend release. Browser products use that host's gateway and session. A custom frontend does not receive a provider key or grant, and cannot choose another host's agents.

An app's server reaches agents under `/apps/v1` and never from a browser: the service credential is a server secret. The
owner signs `consentMessage(...)` (or `setupMessage(...)` for a hosted agent) with NEP-413 in the app; the server submits
it. A consent reaches the listed reads (`APP_READS`) and owner actions (`APP_OWNER`) and, for `owner/prepare`, only
actions the owner can read when signing or that platform code builds entirely (`AppOwnerAction`); everything else is
refused. The app never asks an owner to sign the platform's sign-in text. See the platform's `docs/app-access.md`.
The production host (`api.multiagency.ai`) has served the `/apps/v1` routes since 2026-11-07, on an older platform
version than this package; no app workflow is observed there. Build against the platform repository's local stack
(below), with a simulated provider, chain and wallet; then ask for a staging credential through
[developer access](https://github.com/MultiAgency/platform/blob/main/docs/developer-access.md).

An agent connection permits its contributor's reports and compensation reads only. It cannot file invoices, approve payments, sign owner actions or manage connections. Treasury machine access is a separate existing route and credential; Payables owner delegation and DAO machine delegation are unavailable.

## What the platform does for your product

The NEAR Intents Agent API provider holds the funds, enforces the policy the owner signed (payees, caps, budget, held approvals), prepares the owner actions a wallet or DAO signs, and executes money actions. The platform does the rest of what a product would otherwise build around the provider, and no client of this SDK receives a provider key or grant.

What your product can rely on, and what it still does:

- **Each money action is sent at most once.** One executor per agent sends every action from one place, after a write-ahead record, so a crash, restart or lost reply never sends it again, and an app's `requestId` is honored once. An outcome the platform can't prove stays unresolved and blocks new money actions on that agent. Your product never resends after `unknown`; it reads `activity` and `unresolved` (see Handle outcomes explicitly).
- **What the provider can't check is refused before sending.** The provider enforces the signed policy; the platform also checks that the policy is still the one in force, the grant fits the action, a swap buys an asset the policy lists, a held payout isn't duplicated and a saved plan runs as it was quoted. A recipient that doesn't exist on NEAR is refused before anything is recorded. Your product branches on the refusal's `kind` and code, never its text.
- **Owners approve what they read.** Owner actions are prepared on the platform and completed only by the owner's own signature or a DAO's vote. A vote on a held payout is checked against the provider's own record of that payout, so the approval releases exactly the terms shown. Your product shows what the owner is signing; it never signs for them.
- **Callers are bound to their host, owner and agent.** Sessions are host-local; machine credentials and app consents name one host, agent and owner, expire, and can be revoked. Your product keeps credentials server-side and out of logs and URLs.

What has run where, by the routes each client calls:

| Client | Status |
| --- | --- |
| `ownerClient`, in the owner's session | Mainnet-observed on the hosted platform: reads, owner actions, held-payout votes, and plan execution through the Treasury autopilot |
| `ownerClient` with a machine credential | Offline- and stack-tested; not observed on mainnet |
| `appClient` | Wallet-owned agents: mainnet-observed on platform staging (2026-10-28, 2026-10-30); not in production. DAO-owned (`daoSetups`, `daoConsents`, `daoVotes`): setup, consent, the grant and the DAO's stop mainnet-observed on platform staging (2026-11-04); funding by the DAO's vote and a proposal it approved, then executed, mainnet-observed there (2026-11-05); revoking and policy edits offline-tested only |
| `payeeClient`, in the contributor's session | Mainnet-observed on the hosted invoice entry: invoices and agreement requests (2026-10-12, 2026-10-14) |
| `payeeClient` with a report connection | Offline- and stack-tested; not deployed |
| `payeeClient.policyProof` | Offline-tested; not deployed. The answer is the platform's account of the provider's policy, not independently checkable |

Crash recovery and the refusals above are tested offline, not observed on mainnet. The platform's [mainnet log](https://github.com/MultiAgency/platform/blob/main/docs/mainnet-log.md) records what has run on mainnet, and [enforcement](https://github.com/MultiAgency/platform/blob/main/docs/enforcement.md) what the signed policy guarantees.

## Quickstart: an app's server on the local stack

Ten minutes, no wallet, no funds. Start the platform's local stack, which runs the real gateway and agent servers with
a simulated provider, chain and wallet, and issues your app a credential. It needs Node 24.22 or later, pnpm (through
Corepack) and OpenSSL:

```sh
git clone https://github.com/MultiAgency/platform && cd platform && pnpm install
pnpm test:e2e:stack --treasury --app my-app --no-browser   # prints: Isolated stack ready: <stack>/state.json
```

In your own project (`npm install @multiagency/sdk`, `"type": "module"`), save this as `quickstart.mjs`. It gets the
stack owner's consent (the stack's control files stand in for the owner's wallet) and reads the agent within it:

```js
import { existsSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { randomBytes } from "node:crypto";
import { appClient, consentMessage } from "@multiagency/sdk";

const statePath = process.argv[2];
const state = JSON.parse(readFileSync(statePath, "utf8"));
const base = state.app.base;                             // the platform host, e.g. https://localhost:54321
const host = new URL(base).host;                         // what the owner's signature is bound to
const credential = readFileSync(state.app.credentialFile, "utf8").trim(); // tap_…: a server secret
const { agent, agentId, owner } = state.treasury;        // the stack's Treasury agent and its owner

// The stack's stand-in for the owner's wallet: a control file it answers. A real app asks the owner's wallet instead.
const controls = join(dirname(statePath), "controls");
async function ownerSigns(message) {
  const nonce = randomBytes(32).toString("base64"), name = `sign-${Date.now()}`;
  writeFileSync(join(controls, `${name}.tmp`), JSON.stringify({ command: "signOwner", message, recipient: host, nonce }));
  renameSync(join(controls, `${name}.tmp`), join(controls, `${name}.json`));
  const result = join(controls, `${name}.result.json`);
  while (!existsSync(result)) await new Promise(r => setTimeout(r, 100));
  const answer = JSON.parse(readFileSync(result, "utf8"));
  if (!answer.ok) throw new Error(answer.error);
  return { message, nonce, publicKey: answer.value.publicKey, signature: answer.value.signature };
}

const app = appClient({ base, credential });
// 1. The owner consents: your server builds the exact text, the owner's wallet signs it (NEP-413), your server submits it.
const text = consentMessage({ host, deployment: state.app.deployment, organization: "org_1", owner, agent, agentId,
  scopes: ["read", "treasury"], expiresAt: new Date(Date.now() + 30 * 86_400_000).toISOString() });
const stored = await app.consents.submit(await ownerSigns(text));
if (!stored.ok) throw new Error(`consent: ${JSON.stringify(stored)}`);
// 2. Call the agent within that consent.
const overview = await app.agent("org_1", agent).call("overview");
if (!overview.ok) throw new Error(`overview: ${JSON.stringify(overview)}`);
console.log("agent", overview.value.agentId, "holds", overview.value.book.map(h => `${h.symbol} ${h.usd === null ? "(no price)" : `${h.usd.toFixed(2)} USD`}`).join(", "));
```

Run it with the stack's certificate trusted:

```sh
NODE_EXTRA_CA_CERTS=<stack>/environment/localhost.crt node quickstart.mjs <stack>/state.json
# agent a442…5811 holds wNEAR 0.00 USD, USDC 99.97 USD, ETH 0.00 USD
```

With a real owner, only `ownerSigns` changes: your page asks the owner's wallet to sign the same text with NEP-413
(`signMessage({ message, recipient: host, nonce })` through near-connect), and your server submits what it returns.
Never ask the owner to sign `Sign in to <host>`. The app-server skill covers setup of new agents, owner actions, payouts
and DAO owners; treasury-app covers Treasury proposals.

## First read from a browser product

After signing in on the product's configured host, use the configured agent key:

```ts
import { ownerClient } from "@multiagency/sdk";

const owner = ownerClient({ base: "/a/payout" });
const overview = await owner.call("overview");

if (overview.ok) {
  console.dir(overview.value);
} else {
  console.log(overview.kind);
}
```

Replace `payout` with the key configured for your host. Use the typed response to render your screen. A `session` result needs sign-in; `forbidden` means this identity lacks access. Capability and permission helpers can guide what to display; the server authorizes every request.

The SDK repository's `examples/minimal-prototype` is the browser reference: a page bundled with rsbuild that imports `@multiagency/sdk`, signs in through the gateway, reads its agent and takes one wallet-signed owner action, keeping the prepared action's `correlationId` across a lost reply and a reload. Its end-to-end test runs it on the isolated stack with a simulated provider. Use the public clients rather than reproducing the RPC wire format.

## First read from a contributor agent

Have the contributor start a report connection from their signed-in application. Give the agent the connection token and the API entry base: the origin, or the origin plus `/i/<instance>`. Do not use a page URL ending in `/submit` or `/report` as the API base.

```ts
import { payeeClient } from "@multiagency/sdk/payee";

const entry = process.env.MULTIAGENCY_ENTRY;
const token = process.env.MULTIAGENCY_REPORT_TOKEN;
if (!entry || !token) throw new Error("Provide the contributor API entry and report token.");
if (new URL(entry).protocol !== "https:") throw new Error("Use the HTTPS contributor entry.");

const contributor = payeeClient({ base: entry.replace(/\/$/, ""), token });
const session = await contributor.compensationSession();
if (!session.ok) throw new Error(`Contributor access: ${session.kind}`);

const records = await contributor.compensation();
if (records.ok) {
  console.log(records.value.agreements.map(a => ({
    id: a.id, title: a.terms.title, remainingAtomicUsdc: a.remaining,
  })));
} else {
  console.log(records.kind);
}
```

The token is sent as a bearer without browser cookies. Keep it out of source, URLs and logs. An agent never needs the contributor's wallet key or an exported browser cookie.

## Build the report workflow

1. Read and select the intended agreement. Its scope, period and remaining allowance bound the work; allowance is not an earned amount.
2. Construct the complete report command using the payee-workflows example. Save its request ID, command ID and exact contents before sending.
3. Use `expectedVersion: 0` for a new request. For a revision, keep the request ID and use its current returned version with a new command ID for the new intended change.
4. `submit: false` saves a server draft; `submit: true` sends the report to owner review. Only a draft or a request returned for changes can be revised.
5. An optional report amount is a proposal in atomic USDC: `"12000000"` is 12 USDC. The owner chooses a separate approved amount.
6. After `unknown`, keep the exact command and read the original request by its ID. Recovery is a read. Do not create a replacement or resend automatically. The entry records each `commandId` with its content: sending the identical command again returns the original record, and a different payload under the same `commandId` is refused with `command_conflict`. A missing request after `unknown` does not prove that nothing was recorded.
7. Match the returned payment by request ID. An approved report is not a paid payment: only a payment whose status is `paid` reports recorded settlement. Display the last recorded status as read.

Refusals carry a `code`, for example `stale_request` (the version moved; read it again), `request_locked` (already submitted, approved or declined), `outside_period` (the report period must fit the agreement), `agreement_changed` (a request keeps its first agreement), `not_found`, `intake_full`, `identity_conflict` (the request's `id` is already used), `command_conflict` and `rate_limited`.

Validate fields with `reportCommand.safeParse` before sending. Invalid structured input throws a Zod validation error locally and sends nothing.

## Handle outcomes explicitly

Reads may be repeated after `unavailable`. `session` and `forbidden` require different user actions. A typed refusal says the action did not proceed; correct the stated cause before another intended action. An `unknown` action may have taken effect. Preserve its available identity and follow the documented reads.

The SDK never automatically resubmits an action. Some owner procedures have no caller-held lookup identity; the owner-workflows skill describes their limits. Diagnostic provider request IDs are not verified operation links. An unresolved payment may continue blocking its agent until a supported resolution exists.

## Continue with the bundled guidance

The package contains `skills/getting-started/SKILL.md`, `skills/payee-workflows/SKILL.md`, `skills/owner-workflows/SKILL.md`, `skills/app-server/SKILL.md` and `skills/treasury-app/SKILL.md`. These files describe the clients in the installed package and can be read directly or through TanStack Intent. `CHANGES.md` records consumer-impacting changes.

Use `@multiagency/sdk/schemas/*` for the published JSON schemas. The Node-only `@multiagency/sdk/release-server` serves immutable frontend artifacts; it does not authenticate callers or run a financial executor.

For a local rehearsal, the SDK repository's existing simulated stack supplies the gateway and provider fixtures. Keep simulated sign-in, approvals, funding and settlement visibly separate from the product's SDK calls. A successful simulation does not authorize a hosted deployment or financial action.
