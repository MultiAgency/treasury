---
name: treasury-app
description: >
  Use when an app's server proposes Treasury swaps for an Organization's agent through @multiagency/sdk and has them
  executed once the owner approves later: proposals by requestId, the exact text the owner signs (or a DAO's vote), one
  execution per proposal with recovery by state, or exact owner-signed limit orders with separate consent and fill
  tracking. Server side only. Read app-server first.
metadata:
  purpose: 'Treasury proposals through an app: propose by requestId, the owner signs the exact terms, execute once, recover by state.'
  type: core
  library: '@multiagency/sdk'
  library_version: '0.6.0'
requires:
  - getting-started
  - app-server
sources:
  - 'MultiAgency/platform:src/contract/treasury-proposals.ts'
  - 'MultiAgency/platform:src/contract/limit-orders.ts'
  - 'MultiAgency/platform:src/contract/app-access.ts'
  - 'MultiAgency/platform:src/proposals/service.ts'
  - 'MultiAgency/platform:docs/enforcement.md'
  - 'MultiAgency/platform:docs/limit-orders.md'
---

# Treasury proposals from an app's server

Read app-server first: the same credential, consent and result kinds apply. An agent runtime (your CLI, an assistant)
calls your server, never the platform. A proposal is a list of swaps your app proposes now; the agent's owner approves
its exact terms later (hours or days), by signing a text in their own wallet; then your server asks for its execution,
which runs once, under the owner's signed policy. It is mainnet-observed on the staging host only; build against the SDK
repository's local stack.

Four consent scopes, each named in the text the owner signs:
- `read`, for the owner UI's frame: `account` gives the agent's wallet account and the grant the executor holds
  (`grant`, plus `stagedGrant` while a new one waits to be promoted); `reconcileBooks` gives each balance against its
  independent record. Follow unresolved operations with `unresolved`; the platform reconciles them itself, and an app
  never calls `recover`.
- `treasury`:
  - Treasury reads: `strategy/get`, `autopilot/get`, `autopilot/evidence`, `autopilot/log`, `treasury/get`.
  - Strategy settings (`strategy/save`), which act only once the owner signs a grant binding them.
  - Autopilot on and off (`autopilot/enable`, `autopilot/stop`), and "Run now" (`autopilot/tick`), which swaps only
    under the owner's grant for the saved strategy and within its per-run ceiling.
  - Funding: `sweep`, and `deposit` (a one-time address that credits the agent), then the SDK's `fundingTransaction`
    for the transfer the owner or the DAO signs.
  - For a wallet owner, the linked treasury account (`treasury/link`, `unlink`); refused for a
    DAO-owned agent. Whether a linked DAO is confidential is read from chain (`treasury/get`); nothing sets it.
  - Every `proposals/*` procedure.
- `treasury-execute`, only beside `treasury`: `rebalance`, `externalPlan` and `executePlan`, five-minute plans executed
  within the policy without a signature per swap, and only while the owner's live grant binds the strategy they were
  planned under. The autopilot's per-run ceiling (`autopilot.maxUsd`) doesn't bind them: it applies only to autopilot
  runs, so `maxUsd: 0` doesn't stop these plans. `sweep`, `rebalance` and `executePlan` are streams: read them with `app.agent(...).stream(path, input)`.
- `treasury-orders`, only beside `treasury`: dry order quote, create, get, list, owner approval or rejection, one
  placement, cancellation and status refresh. Existing `treasury` consents do not acquire it. It does not turn on the
  provider's `limit_order` policy action; the owner signs that policy revision separately.

## Where the limits are

The owner's signed policy is the boundary, and the provider enforces it on every path: proposals, `treasury-execute`
and the owner's own actions. It sets per-asset caps per transaction, hour, day and month, and a USD budget across
assets. Per the Agent API's docs, each budget cap runs in fixed daily, weekly or monthly periods counted from when the
owner turned it on, not a rolling window, so up to twice a cap can move across a reset; a smaller shorter cap or a
per-asset hourly limit bounds that. These are absolute amounts, not a share of the treasury, and they bound spending,
not exposure. No consent or credential has a budget of its own, and a
proposal's approval is the platform's check, not the provider's. Limits your app keeps in its own process (a share per
order, orders per hour) are your app's rules, not a boundary: whoever holds the agent's treasury grant can act without
them. To change a limit, the owner signs a policy update. What each limit is known to guarantee:
[enforcement, "The envelope"](https://github.com/MultiAgency/platform/blob/main/docs/enforcement.md#the-envelope).

A cash floor is the one the platform holds for you in the strategy: `cashFloor: { usd, assets }` in `strategy/save`,
whole USD of the public and confidential balance of `assets` (for example `[USDC]`). The platform refuses a swap that
would lower that cash and leave it under `usd`, from every path: the autopilot, "Run now", `executePlan`, proposals.
It never refuses a swap that adds cash, even while cash stays under the floor. A swap out of a named asset counts its
full input, and one into a named asset counts only its floor (`minAmountOut`), at fresh prices. A refused plan stops
with `cash_floor_exceeded` in its journal and a `rejected` problem. A proposal is also checked before its claim, at the
prices read then: a refusal that check foresees is `not_executable` and the proposal stays approved. A price move
between that check and the send can still refuse a swap after the claim.
Leave `cashFloor` out for no floor: there is no default, and a strategy saved without one keeps its digest, so the
grants that bind it stay valid. A floor is part of the strategy, so setting, changing or removing one needs a new grant.
A server that predates the floor drops the field silently: check that the strategy `strategy/save` answers carries
your `cashFloor`. `overview` reports the saved floor as `cashFloor` beside `target`, absent when there is none or the
server predates the field. It doesn't cover money moved any other way: the owner's own withdrawals and payments, or other agents.

## Propose, once per requestId

Store the `requestId` (1–64 of `[A-Za-z0-9_-]`) and the request before calling. `legs` is your chosen swaps in raw units
(at most 8; a `minAmountOut` you require is kept if it is above the quote's floor), or `"strategy"` for the legs a
rebalance toward the owner's strategy picks now. `expiresAt` is at most 7 days ahead.

```ts
import { appClient, proposalText, type ProposalView } from "@multiagency/sdk";

type Request = { requestId: string; legs: { from: string; to: string; amount: string; minAmountOut?: string }[] | "strategy"; expiresAt: string };
type SignNep413 = (message: string, recipient: string, nonce: Uint8Array) => Promise<{ publicKey: string; signature: string }>;

export async function propose(app: ReturnType<typeof appClient>, organization: string, agent: string, request: Request) {
  const calls = app.agent(organization, agent);
  const made = await calls.call("proposals/create", request);
  if (made.ok || (made.kind !== "unknown" && made.kind !== "unavailable")) return made;
  // The answer was lost: the same requestId and request answer the stored proposal and store nothing new.
  return calls.call("proposals/create", request);
}

export async function approve(app: ReturnType<typeof appClient>, organization: string, agent: string, host: string,
  proposal: ProposalView, sign: SignNep413) {
  // The platform accepts only this exact text; show the owner this text, which their wallet shows as it signs.
  const message = proposalText(proposal, "approve");
  const nonce = crypto.getRandomValues(new Uint8Array(32));
  const { publicKey, signature } = await sign(message, host, nonce);
  return app.agent(organization, agent).call("proposals/approve", { id: proposal.id,
    signed: { message, nonce: btoa(String.fromCharCode(...nonce)), publicKey, signature } });
}
```

Result: `{ ok: true, value: proposal }` with `state` `proposed`, then `approved`. The text names each swap with its
floor (the least it may return), the policy revision and strategy it was proposed under, the expiry and the
proposal's sha256; the host is the NEP-413 recipient. Approving records the signature and sends nothing. Refusals carry
`code` (`PROPOSAL_REFUSAL_CODES`): `not_found` (no such proposal from this app), `request_conflict` (another request
under that `requestId`), `expiry_invalid`, `too_many_proposals` (the agent's 32 open proposals), `nothing_to_propose`
(`legs: "strategy"` picked no leg worth its cost), `not_proposable` (a provider warning, an output the policy forbids, a
floor above the quote, cost over the strategy's limit, or a balance short: the message says which),
`signature_invalid`, `already_approved` (another signature approved it), `policy_not_in_force` (the policy isn't
enforced now; the approval wasn't recorded), `invalidated` (the policy, strategy or agent changed since: propose
again), `not_open`, `expired`, `withdrawn` (made under a consent that has since ended). Executing adds `not_approved`
and `not_executable` (not now: the message says why, and the proposal stays approved unless it says otherwise). The owner
rejects with `proposalText(proposal, "reject")` and `proposals/reject`; your app withdraws with `proposals/withdraw`.

## Execute once, and follow it

```ts
import { appClient } from "@multiagency/sdk";

export async function execute(app: ReturnType<typeof appClient>, organization: string, agent: string, id: string) {
  const calls = app.agent(organization, agent);
  const ran = await calls.call("proposals/execute", { id });
  if (ran.ok || (ran.kind !== "unknown" && ran.kind !== "unavailable")) return ran;
  // The answer was lost: read the proposal. Never propose the same swaps again because of a lost answer.
  return calls.call("proposals/get", { id });
}
```

Result: the proposal, `state`:
- `executed`: every swap succeeded; `operations` lists them.
- `stopped`: claimed, then a swap didn't succeed or was refused, or nothing was sent. It never runs again: propose the
  rest anew.
- `unknown`: a swap's outcome isn't proven. It blocks the agent's sends until resolved and is never resent: read later.
- `executing`: running now; read later.
- `invalidated`, `expired`, `rejected`, `withdrawn`: it ended without running.

A refusal `not_executable` means the attempt was refused before anything was claimed (price below a signed floor, a
provider warning, a short balance, no live treasury grant, the policy not in force): nothing was sent, the proposal
stays `approved`, and asking again later is safe. `not_approved`: the owner hasn't approved it. Execution re-quotes
every swap and sends each with a floor at least the signed one.

## A DAO-owned treasury: the DAO approves by vote

When `identity` answers `signer: "dao"`, the DAO approves or rejects a proposal by its vote. The platform files the
vote from the proposal's own text; your app never builds or relays an approval text (app-server, "A DAO owner").

```ts
import { appClient } from "@multiagency/sdk";

type MemberSigns = (transaction: { receiverId: string; actions: readonly unknown[] }) => Promise<void>;

/** The DAO's vote on one of your proposals: reading its state after the vote passed relays it; then execute as usual. */
export async function daoApprove(app: ReturnType<typeof appClient>, organization: string, agent: string, proposal: string,
  memberSigns: MemberSigns, memberVotes: boolean) {
  const filed = await app.daoVotes.file({ organization, agent, proposal, verdict: "approve" });
  if (!filed.ok) return filed;
  const transaction = memberVotes && filed.value.transactions.proposalAndVote ? filed.value.transactions.proposalAndVote : filed.value.transactions.proposal;
  if (transaction) await memberSigns(transaction);
  // `pending` until the vote passes: read again later with the same id.
  return app.daoVotes.state(filed.value.request.id);
}
```

Result: `pending`, then `relayed` with `proposalState` (`approved`). Nothing relays the vote until your server reads
`state` after it passed: keep reading until it's final. Then `execute(...)` as above. A vote must pass
before the proposal's `expiresAt` and while the DAO consent it is filed under is live. Proposals have no provider
window, so they suit a DAO whose votes take hours or days; the strategy grant autopilot needs is a provider intent that
expires in about 290 s, which only a DAO voting that fast can sign (app-server, "A DAO owner"). A swap's signed floor may be out
of reach by then: execution is refused `not_executable` and the proposal stays approved.

Unattended swaps are the DAO's grant vote: the `treasury` grant, prepared with `owner/prepare` and `signer: "dao"`,
binds the saved strategy. Its proposal says it authorizes swaps without a vote each time and names that strategy (its
digest suffix, targets, cost cap, the autopilot's per-run ceiling and any cash floor, which the proposal makes
public); show members the same terms from `strategy/get`
before they vote. Under it, autopilot runs once your app turns it on (`autopilot/enable`), and with `treasury-execute`
(only if the DAO voted it into its consent) your plans run. Saving another strategy needs a new grant vote, and
invalidates open proposals: the next read of each answers `invalidated`.

Freezing and unfreezing the agent (`agent_freeze`, `agent_unfreeze`) are DAO votes too, prepared like the grant with
`owner/prepare` and `signer: "dao"` (app-server, "A DAO owner"). The grant, its revocation, a policy edit, freeze and
unfreeze are each a provider owner intent with a fixed window that nothing lengthens: 600 s for wallet requests
(creation, freeze, unfreeze, on-chain policy edits) and about 290 s for consent messages (the grant, a revocation,
off-chain policy edits), per the provider's docs read 2026-11-05. The DAO's delegate action stays valid on chain for
6,000 blocks, but the provider's expiry comes first. Show members `expiresAt`: only a vote that passes before it
completes the action, so a slower DAO can't freeze its agent by vote. The DAO's own stop
(`/confirm/dao/stop/<dao>/<agent>`) ends app consents and turns autopilot off, but neither freezes the agent nor
revokes the grant: under a consent the DAO votes later, an app can turn autopilot on again.

## Resting limit orders (SDK 0.5.8, offline-tested)

Read `app.capabilities()` with the app server's service credential and offer order controls only when it advertises
`treasury-limit-orders-v1` and a distinct owner consent carries both `treasury` and `treasury-orders`. The headless
platform host has no `/gw/me`; a capability advertises its app route, not consent, an active agent release, or
deployed provider support. Keep the credential on the app server.

Use `treasury-orders` only when the owner wants to sign **each exact order**. The provider SDK 0.8.2 interprets
`quantity` as atomic base units and `price` as human quote units per whole base unit. Provide an explicit deadline
between one minute and seven days ahead, and an owner approval expiry no later than that deadline. A dry
`limitOrders/quote` moves nothing; check its warnings and exact atomic spend before showing the terms. The default
policy does not allow `limit_order`. An owner must sign a policy update that enables it and sets the provider's
deviation bound. A configured Treasury cash floor refuses placement until a proven reservation rule exists.

Save a stable `requestId` and terms before `limitOrders/create`. A lost create answer may be retried with that exact
body. The returned `LimitOrderView` supplies `sha256`; use the SDK's `limitOrderText(view, "approve")` as the exact
NEP-413 message the wallet signs with recipient the platform host. Relay it to `limitOrders/approve`; this sends
no funds. For a DAO owner, file `app.daoLimitOrders.file({ organization, agent, order: view.id, verdict: "approve" })`,
have an authorized member file or vote on the returned transaction, then follow `.state(request.id)` until the
signature is relayed. A relay attempt is saved before its agent call; an uncertain answer is poll-only and requires
the agent's matching signature receipt. The app must enforce its member roles as it does for other DAO votes.

Call `limitOrders/place` once after approval. A lost answer is followed by `limitOrders/get` and `refresh` using the
same ID, never by a new request. Provider placement `SUCCESS` means funded/resting, not filled. Show partial fills,
final payout and `unknown` separately. `limitOrders/cancel` is a one-way request without a provider idempotency key.
After an ambiguous reply, read `refresh`. Repeat `cancel` for the same ID only when the view explicitly says
`cancelMayResume === true`: a matching claim and journal prove the platform never began its provider POST. Once a
submission attempt is recorded, `cancelMayResume` is false and all recovery is read-only. A completed order needs a
closed fill and final completed payouts.
No live placement, fill, payout or cancellation through this platform has been observed. Production provider order
routes were absent in the 2026-11-10 read-only check. See [limit orders](https://github.com/MultiAgency/platform/blob/main/docs/limit-orders.md).

## Common mistakes

- **Building your own approval text** (CRITICAL): sign only `proposalText(proposal, "approve")` from the proposal the
  platform returned; any other text is refused, and a summary of yours is not what the owner signs.
- **A new requestId after `unknown`** (CRITICAL): the swaps may have run. Read `proposals/get`.
- **Treating `stopped` as nothing sent** (HIGH): read `operations`; a swap may have succeeded before it stopped.
- **Asking for `treasury-execute` when proposals suffice** (HIGH): it lets your app swap within the policy without a
  signature per swap. Ask for it only when the owner wants unattended execution.

## Completion

Every proposal you created has a read state; none reads `unknown` or `executing` without a later `proposals/get`.
Report anything you could not read; do not act again.
