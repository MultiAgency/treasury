# @multiagency/sdk changes

Every SDK change appends a note under **Unreleased** when it is made: what changed for the apps, and any wire change
all apps must update for together. A release candidate sets the version in `package-version.ts` and puts its heading
over the notes. Under 0.x, any public-interface change bumps at least the minor version.

## Unreleased

## 0.0.1 (2026-10-18)

Numbering restarts at 0.0.1; the earlier local tarballs (`@multiagency/proto-contract` 1.0.0–1.5.0, `@multiagency/sdk`
1.6.0) are history. No backwards compatibility with them.

- Package `@multiagency/proto-contract` → `@multiagency/sdk`. Payee entry `./supplier` → `./payee`.
- Payee names in code: `payeeClient`, `payeeContract`, `compatiblePayeeFrontend`, `payeeWorkOrderRequest`,
  `payeeCompensationView`, `PAYEE_REPORT_PERMISSIONS`. No aliases.
- **Wire change, all apps together:** an agent connection's `role` is `"payee"` (`PAYEE_ROLE`). 1.5.0 clients (Invoices G
  and earlier) reject it, so those releases are not rollback targets across this change.
- Hosted contributor sessions signed before this release end once (their session key derivation changed).
- Unchanged on the wire: routes, `supplier-*-v1` capability ids, cookies, records.
- Agent guidance ships as TanStack Intent skills: `getting-started`, `owner-workflows`, `payee-workflows`
  (`npx @tanstack/intent@0.5.5 list`). Every example is typechecked and run against the packed tarball.
